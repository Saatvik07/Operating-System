#include<stdio.h>
int main(){
    int variable1 = 1234;
int variable2 = 56789;
printf("Variable 1: %d \nVariable 2: %d\n",variable1,variable2);
    return 0;
}